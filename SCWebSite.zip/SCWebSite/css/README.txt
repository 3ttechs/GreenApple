This directory was copied on 5Mar2016 from the folder C:\Users\Tony Jacob\Xylem\SmartClinic\ResponsiveWebsiteDesign\Smart Clinic Web\flat-admin-bootstrap-templates-master
(Given by Lakshmy)